#!/usr/bin/env python3
"""Serve the prebuilt Horizon WebGPU demo locally. Requires Python 3."""
import argparse
import functools
import http.server
from pathlib import Path

class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map, '.wasm': 'application/wasm'}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=3000)
    args = parser.parse_args()
    handler = functools.partial(Handler, directory=str(Path(__file__).resolve().parent))
    try:
        with http.server.ThreadingHTTPServer(('127.0.0.1', args.port), handler) as server:
            print(f'Open http://localhost:{args.port} in a WebGPU-capable browser.', flush=True)
            print('Press Ctrl+C in this terminal to stop.', flush=True)
            server.serve_forever()
    except KeyboardInterrupt:
        pass
