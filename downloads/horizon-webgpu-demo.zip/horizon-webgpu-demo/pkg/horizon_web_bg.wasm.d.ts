/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const start: () => any;
export const wasm_bindgen_d04fdc24128f088b___convert__closures_____invoke___f64______true_: (a: number, b: number, c: number) => void;
export const wasm_bindgen_d04fdc24128f088b___convert__closures_____invoke___js_sys_53d85e458377bf7f___Function_fn_wasm_bindgen_d04fdc24128f088b___JsValue_____wasm_bindgen_d04fdc24128f088b___sys__Undefined___js_sys_53d85e458377bf7f___Function_fn_wasm_bindgen_d04fdc24128f088b___JsValue_____wasm_bindgen_d04fdc24128f088b___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
export const wasm_bindgen_d04fdc24128f088b___convert__closures_____invoke___wasm_bindgen_d04fdc24128f088b___JsValue__core_37ee0ce0c4cd57d5___result__Result_____wasm_bindgen_d04fdc24128f088b___JsError___true_: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen_d04fdc24128f088b___convert__closures_____invoke___wasm_bindgen_d04fdc24128f088b___sys__JsNullable_wgpu_75b4ab5856c37468___backend__webgpu__webgpu_sys__gen_GpuError__GpuError___core_37ee0ce0c4cd57d5___result__Result_____wasm_bindgen_d04fdc24128f088b___JsError___true_: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen_d04fdc24128f088b___convert__closures_____invoke___wasm_bindgen_d04fdc24128f088b___sys__JsNullable_wgpu_75b4ab5856c37468___backend__webgpu__webgpu_sys__gen_GpuError__GpuError___core_37ee0ce0c4cd57d5___result__Result_____wasm_bindgen_d04fdc24128f088b___JsError___true__8: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen_d04fdc24128f088b___convert__closures_____invoke___wasm_bindgen_d04fdc24128f088b___sys__JsNullable_wgpu_75b4ab5856c37468___backend__webgpu__webgpu_sys__gen_GpuError__GpuError___core_37ee0ce0c4cd57d5___result__Result_____wasm_bindgen_d04fdc24128f088b___JsError___true__9: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen_d04fdc24128f088b___convert__closures_____invoke___web_sys_ccf2cdac4e7e161b___features__gen_Event__Event______true_: (a: number, b: number, c: any) => void;
export const wasm_bindgen_d04fdc24128f088b___convert__closures_____invoke___wgpu_75b4ab5856c37468___backend__webgpu__webgpu_sys__gen_GpuDeviceLostInfo__GpuDeviceLostInfo______true_: (a: number, b: number, c: any) => void;
export const wasm_bindgen_d04fdc24128f088b___convert__closures_____invoke___wgpu_75b4ab5856c37468___backend__webgpu__webgpu_sys__gen_GpuDeviceLostInfo__GpuDeviceLostInfo______true__7: (a: number, b: number, c: any) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_destroy_closure: (a: number, b: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
