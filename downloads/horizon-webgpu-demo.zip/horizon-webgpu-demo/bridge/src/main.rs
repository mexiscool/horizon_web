//! Fixed-target WebSocket ↔ TCP transport. This does not implement or port a game server.
use std::{
    io::{self, Read, Write},
    net::{TcpListener, TcpStream, ToSocketAddrs},
    sync::{
        Arc,
        atomic::{AtomicUsize, Ordering},
    },
    time::Duration,
};
use tungstenite::{
    Error, Message,
    handshake::server::{ErrorResponse, Request, Response},
};
fn would_block(error: &Error) -> bool {
    matches!(error,Error::Io(e) if e.kind()==io::ErrorKind::WouldBlock)
}
#[allow(clippy::result_large_err)] // tungstenite requires an HTTP response by value in its callback.
fn relay(
    stream: TcpStream,
    target: std::net::SocketAddr,
    origins: Arc<Vec<String>>,
) -> Result<(), Box<dyn std::error::Error>> {
    stream.set_read_timeout(Some(Duration::from_secs(10)))?;
    stream.set_write_timeout(Some(Duration::from_secs(10)))?;
    let callback =
        move |request: &Request, response: Response| -> Result<Response, ErrorResponse> {
            let origin = request
                .headers()
                .get("origin")
                .and_then(|s| s.to_str().ok());
            if !origin.is_some_and(|o| origins.iter().any(|allowed| allowed == o)) {
                let mut rejected =
                    ErrorResponse::new(Some("Origin is not allowed by this bridge".into()));
                *rejected.status_mut() = tungstenite::http::StatusCode::FORBIDDEN;
                return Err(rejected);
            }
            Ok(response)
        };
    let mut ws = tungstenite::accept_hdr_with_config(
        stream,
        callback,
        Some(
            tungstenite::protocol::WebSocketConfig::default()
                .max_write_buffer_size(16 * 1024 * 1024)
                .max_message_size(Some(8 * 1024 * 1024))
                .max_frame_size(Some(8 * 1024 * 1024)),
        ),
    )?;
    let mut tcp = TcpStream::connect_timeout(&target, Duration::from_secs(10))?;
    tcp.set_nodelay(true)?;
    tcp.set_nonblocking(true)?;
    ws.get_mut().set_read_timeout(None)?;
    ws.get_mut().set_write_timeout(None)?;
    ws.get_mut().set_nonblocking(true)?;
    let mut pending = Vec::new();
    let mut offset = 0;
    let mut buffer = [0u8; 65536];
    let mut to_ws = None;
    loop {
        if pending.len() - offset > 16 * 1024 * 1024 {
            return Err("Client backpressure exceeds 16 MiB".into());
        }
        if offset < pending.len() {
            match tcp.write(&pending[offset..]) {
                Ok(0) => return Ok(()),
                Ok(n) => offset += n,
                Err(e) if e.kind() == io::ErrorKind::WouldBlock => {}
                Err(e) => return Err(e.into()),
            }
        }
        if offset == pending.len() {
            pending.clear();
            offset = 0;
        }
        match ws.flush() {
            Ok(()) => {}
            Err(e) if would_block(&e) => {}
            Err(Error::ConnectionClosed) => return Ok(()),
            Err(e) => return Err(e.into()),
        }
        match ws.read() {
            Ok(Message::Binary(bytes)) => {
                if pending.len() + bytes.len() > 16 * 1024 * 1024 {
                    return Err("Client packet queue exceeds 16 MiB".into());
                }
                pending.extend_from_slice(&bytes);
            }
            Ok(Message::Close(_)) => {
                let _ = ws.flush();
                return Ok(());
            }
            Ok(Message::Text(_)) => {
                return Err("The Minecraft bridge accepts binary messages only".into());
            }
            Ok(_) => {}
            Err(e) if would_block(&e) => {}
            Err(Error::ConnectionClosed | Error::AlreadyClosed) => return Ok(()),
            Err(e) => return Err(e.into()),
        }
        if to_ws.is_none() {
            match tcp.read(&mut buffer) {
                Ok(0) => {
                    let _ = ws.close(None);
                    let _ = ws.flush();
                    return Ok(());
                }
                Ok(n) => to_ws = Some(Message::Binary(buffer[..n].to_vec().into())),
                Err(e) if e.kind() == io::ErrorKind::WouldBlock => {}
                Err(e) => return Err(e.into()),
            }
        }
        if let Some(message) = to_ws.take() {
            match ws.send(message) {
                Ok(()) => {}
                Err(Error::WriteBufferFull(message)) => to_ws = Some(message),
                Err(e) if would_block(&e) => {}
                Err(e) => return Err(e.into()),
            }
        }
        std::thread::sleep(Duration::from_millis(1));
    }
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().skip(1).collect();
    if args.iter().any(|a| a == "--help" || a == "-h") {
        println!(
            "horizon-web-bridge [--listen 127.0.0.1:25566] [--server 127.0.0.1:25565] [--origin http://localhost:3000] (repeat --origin to allow more pages)"
        );
        return Ok(());
    }
    if args.len() % 2 != 0 {
        return Err("Options require values; use --help".into());
    }
    let mut listen = "127.0.0.1:25566".to_owned();
    let mut server = "127.0.0.1:25565".to_owned();
    let mut origins = Vec::new();
    for pair in args.as_chunks::<2>().0 {
        match pair[0].as_str() {
            "--listen" => listen = pair[1].clone(),
            "--server" => server = pair[1].clone(),
            "--origin" => origins.push(pair[1].clone()),
            _ => return Err(format!("Unknown option {}", pair[0]).into()),
        }
    }
    if origins.is_empty() {
        origins = vec![
            "http://localhost:3000".into(),
            "http://127.0.0.1:3000".into(),
        ];
    }
    let target = server
        .to_socket_addrs()?
        .next()
        .ok_or("Server address did not resolve")?;
    let listener = TcpListener::bind(&listen)?;
    println!(
        "WebSocket ws://{listen} → TCP {server}\nAllowed page origins: {}",
        origins.join(", ")
    );
    let origins = Arc::new(origins);
    let count = Arc::new(AtomicUsize::new(0));
    for incoming in listener.incoming() {
        let stream = incoming?;
        if count.fetch_add(1, Ordering::SeqCst) >= 16 {
            count.fetch_sub(1, Ordering::SeqCst);
            continue;
        }
        let origins = origins.clone();
        let count = count.clone();
        std::thread::spawn(move || {
            if let Err(e) = relay(stream, target, origins) {
                eprintln!("Bridge connection ended: {e}");
            }
            count.fetch_sub(1, Ordering::SeqCst);
        });
    }
    Ok(())
}
