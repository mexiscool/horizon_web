HORIZON WEBGPU DEMO - PREBUILT

1. Extract this ZIP to a folder on your computer.
2. Install Python 3 if needed: https://www.python.org/downloads/
3. Open a terminal in the extracted horizon-webgpu-demo folder.
4. Start the local server:
   macOS / Linux: python3 start_demo.py
   Windows:       py start_demo.py
5. Open http://localhost:3000 in a current WebGPU-capable browser.
   Chrome or Edge with hardware acceleration enabled are good starting points.
6. Click Play world.

This localhost address works because the server is now running on YOUR computer.
The files are already compiled; you do not need Rust, Cargo, Node or Minecraft.
Keep the terminal running while playing. Press Ctrl+C to stop it.
If port 3000 is occupied, add --port 8080 and open http://localhost:8080.

CONTROLS
WASD / arrows: move        Mouse: look
Space: jump               Shift: sprint
Left click: mine          Right click: place
1-5 / wheel: block        F: toggle flight
Space / Left Ctrl: fly up/down
R: respawn                Esc: pause/release mouse

The paused menu lets you regenerate the island with a numeric seed.
Edits last until regeneration or page reload. This is an experimental browser
slice of Horizon, not the full native game. Terrain/materials are original demo
content. Mobs, crafting, persistent saves and multiplayer are not implemented.

RENDERING
Rust/WebAssembly using wgpu's WebGPU backend, textured voxel geometry,
sun shadows, ambient occlusion, MSAA, atmospheric sky and animated translucent water.
WebGPU is required; there is no WebGL fallback. All runtime files are local.

LICENSES
Original project license: LICENSE.txt
Bundled fonts: fonts/OFL-Geist.txt and fonts/OFL-PixelifySans.txt
